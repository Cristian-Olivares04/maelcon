INSERT INTO TBL_CATEGORIAS(CATEGORIA, DESCRIPCION)
VALUES	('Bombillos', 'variedad de focos y lamparas'),
		('Cables', 'Cables de variedad THWN y simples'),
        ('Hogar','Variedad de tomas, piñas y protectores');

INSERT INTO TBL_CLIENTES(NOMBRE_CLIENTE, RTN, DIRECCION_CLIENTE, TELEFONO_CLIENTE)
VALUES  ('Juan Perez', '08017847756123', 'Col. Palmira', '9984-5741'),
		('Maria Teresa', '08017843656473', 'Col. Mira montes', '9984-5742'),
        ('Jose Monguia', '08017845619741', 'Col. Kennedy', '9984-5743'),
        ('Fabricio Hernandez', '0801741456123', 'Col. Palmira', '9984-5744'),
        ('Kenneth Avila', '08017123650123', 'Col. Cerro Grande', '9984-5745'),
        ('Ester Lopez', '08017845677485', 'Barrio la Hoya', '9984-5746');
        
INSERT INTO TBL_METODOS_PAGO(FORMA_PAGO, DESCRIPCION)
VALUES	('Efectivo', 'Pago unitario'),
		('Credito', 'control de pagos segun acuerdo'),
        ('Tarjeta de credito', 'Visa o MasterCard');
	
INSERT INTO TBL_MP_PUESTO(PUESTO, DESCRIPCION_PUESTO)
VALUES  ('Gerente general', 'Gerente general de tienda'),
		('Ejecutivo de ventas', 'Encargado de concretar las ventas y cotizaciones con los clientes'),
        ('Ejecutivo de compra', 'Analizis de las mejores ofertas de productos y compras del mismo'),
        ('Encargado de bodega', 'Control general de la entrada y salida de material'),
        ('Atención al cliente', 'Encargado de resolver dudas y reclamos de los clientes'),
        ('Mantenimiento', 'Personal de reparación, aseo y vigilancia.');
        
INSERT INTO TBL_OBJETOS(OBJETOS, TIPO_OBJETO, DESCRIPCION, FECHA_CREACION, CREADO_POR, FECHA_MODIFICACION, MODIFICADO_POR)
VALUES	('Administracion', 'Administración', 'Ninguna', NOW(), 1, NOW(), 1),
		('Compras', 'Gestion', 'Ninguna', NOW(), 1, NOW(), 1),
        ('Ventas', 'Gestion', 'Ninguna', NOW(), 1, NOW(), 1),
        ('Inventario', 'Control', 'Ninguna', NOW(), 1, NOW(), 1),
        ('Seguridad', 'Administración', 'Ninguna', NOW(), 1, NOW(), 1),
        ('Ayuda', 'Informativo', 'Ninguna', NOW(), 1, NOW(), 1);
        
INSERT INTO TBL_MS_ROLES(ROL, DESCRIPCION, FECHA_CREACION, CREADO_POR, FECHA_MODIFICACION, MODIFICADO_POR)
VALUES	('Admin', 'Ninguna', NOW(), 1, NOW(), 1),
		('Analista de compras', 'Ninguna', NOW(), 1, NOW(), 1),
        ('Cajero', 'Ninguna', NOW(), 1, NOW(), 1),
        ('Gerente de inventario', 'Ninguna', NOW(), 1, NOW(), 1),
        ('Control de productos', 'Ninguna', NOW(), 1, NOW(), 1);
        
INSERT INTO TBL_PROVEEDORES(RTN, NOMBRE_PROVEEDOR, TELEFONO_PROVEEDOR, CORREO_PROVEEDOR)
VALUES	('0102147484451', 'LUMEX', '9915-2020', 'lumex@correo.com'),
		('0102147478964', 'START', '9915-2021', 'start@correo.com'),
        ('0102174441578', 'LINEAS', '9915-2022', 'lineas@correo.com'),
        ('0801114578513', 'MATER', '9915-2020', 'mater@correo.com'),
        ('0102777458711', 'SERVLUX', '9915-2020', 'servlux@correo.com');

DELIMITER $$
CALL CREAR_PERMISOS( 1, 1, TRUE, TRUE, TRUE, TRUE, 1, @MENSAJE, @CODIGO);
CALL CREAR_PERMISOS( 2, 1, TRUE, TRUE, TRUE, TRUE, 1, @MENSAJE, @CODIGO);
CALL CREAR_PERMISOS( 3, 1, TRUE, TRUE, TRUE, TRUE, 1, @MENSAJE, @CODIGO);
CALL CREAR_PERMISOS( 4, 1, TRUE, TRUE, TRUE, TRUE, 1, @MENSAJE, @CODIGO);
CALL CREAR_PERMISOS( 5, 1, TRUE, TRUE, TRUE, TRUE, 1, @MENSAJE, @CODIGO);
CALL CREAR_PERMISOS( 6, 1, TRUE, TRUE, TRUE, TRUE, 1, @MENSAJE, @CODIGO);
CALL CREAR_PRODUCTO(1, 'Foco 1', 'LUX', 'bajas potencias para zonas amplias',' img.jpg', 1, 1, @MENSAJE, @CODIGO);
CALL CREAR_PRODUCTO(2, 'Foco 2', 'TERX', 'Luz de interiores',' img.jpg', 1, 1, @MENSAJE, @CODIGO);
CALL CREAR_PRODUCTO(3, 'Foco 3', 'ILUMINA', 'Ideal para exteriores',' img.jpg', 1, 1, @MENSAJE, @CODIGO);
CALL CREAR_PRODUCTO(2, 'Foco 4', 'SUR', 'compuesto',' img.jpg', 1, 1, @MENSAJE, @CODIGO);
CALL CREAR_PRODUCTO(1, 'Foco 5', 'CLEND', 'Sin detalles',' img.jpg', 1, 1, @MENSAJE, @CODIGO);
CALL ENCABEZADO_COMPRA(1, 1, 1, 'NINGUNA', @MENSAJE, @CODIGO, @ID);
CALL ENCABEZADO_COMPRA(1, 1, 1, 'NINGUNA', @MENSAJE, @CODIGO, @ID);
CALL ENCABEZADO_COMPRA(1, 1, 2, 'NINGUNA', @MENSAJE, @CODIGO, @ID);
CALL ENCABEZADO_COMPRA(1, 1, 3, 'NINGUNA', @MENSAJE, @CODIGO, @ID);
CALL ENCABEZADO_COMPRA(1, 1, 3, 'NINGUNA', @MENSAJE, @CODIGO, @ID);
CALL ENCABEZADO_COMPRA(1, 1, 2, 'NINGUNA', @MENSAJE, @CODIGO, @ID);
CALL AGREGAR_PRODUCTO_COMPRA(1, 1, 19.23, 'NINGUNA', 80, @MENSAJE, @CODIGO);
CALL AGREGAR_PRODUCTO_COMPRA(2, 1, 16.23, 'NINGUNA', 46, @MENSAJE, @CODIGO);
CALL AGREGAR_PRODUCTO_COMPRA(3, 1, 13.40, 'NINGUNA', 10, @MENSAJE, @CODIGO);
CALL AGREGAR_PRODUCTO_COMPRA(4, 1, 16.00, 'NINGUNA', 15, @MENSAJE, @CODIGO);
CALL AGREGAR_PRODUCTO_COMPRA(2, 2, 14.36, 'NINGUNA', 10, @MENSAJE, @CODIGO);
CALL AGREGAR_PRODUCTO_COMPRA(3, 3, 21.65, 'NINGUNA', 45, @MENSAJE, @CODIGO);
CALL AGREGAR_PRODUCTO_COMPRA(4, 4, 12.54, 'NINGUNA', 50, @MENSAJE, @CODIGO);
CALL AGREGAR_PRODUCTO_COMPRA(5, 5, 15.00, 'NINGUNA', 30, @MENSAJE, @CODIGO);
CALL PROCESAR_COMPRA(1, 1, @MENSAJE, @CODIGO);
CALL PROCESAR_COMPRA(2, 1, @MENSAJE, @CODIGO);
CALL MODIFICAR_INVENTARIO(1, 28.50, 1, @MENSAJE, @CODIGO);
CALL MODIFICAR_INVENTARIO(2, 26.25, 1, @MENSAJE, @CODIGO);
CALL MODIFICAR_INVENTARIO(3, 24.30, 1, @MENSAJE, @CODIGO);
CALL MODIFICAR_INVENTARIO(4, 23.40, 1, @MENSAJE, @CODIGO);
CALL MODIFICAR_INVENTARIO(5, 29.50, 1, @MENSAJE, @CODIGO);
CALL CREAR_ENCABEZADO_VENTA(1, 1, 2, 'NINGUNA', @MENSAJE, @CODIGO);
CALL CREAR_ENCABEZADO_VENTA(2, 1, 1, 'NINGUNA', @MENSAJE, @CODIGO);
CALL CREAR_ENCABEZADO_VENTA(3, 1, 3, 'NINGUNA', @MENSAJE, @CODIGO);
CALL CREAR_ENCABEZADO_VENTA(2, 1, 6, 'NINGUNA', @MENSAJE, @CODIGO);
CALL AGREGAR_PRODUCTO_VENTA(1, 1, 1, @MENSAJE, @CODIGO);
CALL AGREGAR_PRODUCTO_VENTA(2, 1, 1, @MENSAJE, @CODIGO);
CALL AGREGAR_PRODUCTO_VENTA(3, 1, 1, @MENSAJE, @CODIGO);
CALL AGREGAR_PRODUCTO_VENTA(1, 2, 1, @MENSAJE, @CODIGO);
CALL AGREGAR_PRODUCTO_VENTA(3, 3, 1, @MENSAJE, @CODIGO);
CALL AGREGAR_PRODUCTO_VENTA(4, 4, 1, @MENSAJE, @CODIGO);
CALL PROCESAR_VENTA(1, 1, @MENSAJE, @CODIGO);
CALL PROCESAR_VENTA(2, 1, @MENSAJE, @CODIGO);
DELIMITER;