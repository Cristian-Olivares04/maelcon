import app from "./app";

app.listen(3000, () =>
  console.log("Ejecutando el server en el puerto 3000...")
);
