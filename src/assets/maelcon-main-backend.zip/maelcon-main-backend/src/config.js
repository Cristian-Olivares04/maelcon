export default {
    SECRET: 'product-api'
}