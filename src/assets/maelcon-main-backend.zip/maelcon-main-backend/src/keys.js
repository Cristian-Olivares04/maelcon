export default {
  database: {
    host: "exbodcemtop76rnz.cbetxkdyhwsb.us-east-1.rds.amazonaws.com",
    user: "aadz3ubouj3nh23f",
    database: "r9chzvo1zujwufi0",
    password: "tuy0n5alc8t8zm1i",
  },
};
